package com.example.pokemvvmsample.service.repository

import com.example.pokemonmvvmsample.service.model.PokemonList
import retrofit2.Call
import retrofit2.http.GET

interface PokemonService {

    @GET("pokemon?limit=151")
    fun getPokemonList(): Call<PokemonList>
}