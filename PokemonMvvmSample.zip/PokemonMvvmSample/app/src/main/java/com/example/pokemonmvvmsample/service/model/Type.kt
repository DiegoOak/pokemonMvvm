package com.example.pokemvvmsample.service.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Type {
    @SerializedName("slot")
    @Expose
    private val slot: Int? = null
    @SerializedName("type")
    @Expose
    private val typeDesc: TypeDesc? = null
}