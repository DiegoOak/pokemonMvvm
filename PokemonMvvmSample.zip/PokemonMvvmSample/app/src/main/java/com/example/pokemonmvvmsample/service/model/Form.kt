package com.example.pokemonmvvmsample.service.model

import com.google.gson.annotations.Expose

import com.google.gson.annotations.SerializedName




class Form {
    @SerializedName("name")
    @Expose
    private val name: String? = null
    @SerializedName("url")
    @Expose
    private val url: String? = null
}