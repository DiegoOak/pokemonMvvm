package com.example.pokemvvmsample.service.model

import com.example.pokemonmvvmsample.service.model.Ability
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName


class Pokemon {
    @SerializedName("id")
    @Expose
    private val id: Int? = null
    @SerializedName("name")
    @Expose
    private val name: String? = null
    @SerializedName("base_experience")
    @Expose
    private val baseExperience: Int? = null
    @SerializedName("height")
    @Expose
    private val height: Int? = null
    @SerializedName("is_default")
    @Expose
    private val isDefault: Boolean? = null
    @SerializedName("order")
    @Expose
    private val order: Int? = null
    @SerializedName("weight")
    @Expose
    private val weight: Int? = null
    @SerializedName("abilities")
    @Expose
    private val abilities: List<Ability>? = null
    @SerializedName("sprites")
    @Expose
    private val sprites: Sprites? = null
    @SerializedName("stats")
    @Expose
    private val stats: List<Status>? = null
    @SerializedName("types")
    @Expose
    private val types: List<Type>? =
        null
}