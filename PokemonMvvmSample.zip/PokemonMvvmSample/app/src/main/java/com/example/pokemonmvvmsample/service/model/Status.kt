package com.example.pokemvvmsample.service.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Status {
    @SerializedName("base_stat")
    @Expose
    private val baseStat: Int? = null
    @SerializedName("effort")
    @Expose
    private val effort: Int? = null
    @SerializedName("stat")
    @Expose
    private val statusDesc: StatusDesc? = null
}