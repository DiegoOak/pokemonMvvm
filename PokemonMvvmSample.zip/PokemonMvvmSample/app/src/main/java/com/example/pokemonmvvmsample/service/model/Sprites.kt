package com.example.pokemvvmsample.service.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Sprites {
    @SerializedName("back_default")
    @Expose
    private val backDefault: String? = null
    @SerializedName("back_female")
    @Expose
    private val backFemale: Any? = null
    @SerializedName("back_shiny")
    @Expose
    private val backShiny: String? = null
    @SerializedName("back_shiny_female")
    @Expose
    private val backShinyFemale: Any? = null
    @SerializedName("front_default")
    @Expose
    private val frontDefault: String? = null
    @SerializedName("front_female")
    @Expose
    private val frontFemale: Any? = null
    @SerializedName("front_shiny")
    @Expose
    private val frontShiny: String? = null
    @SerializedName("front_shiny_female")
    @Expose
    private val frontShinyFemale: Any? = null
}