package com.example.pokemvvmsample.service.model

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class TypeDesc {
    @SerializedName("name")
    @Expose
    private val name: String? = null
    @SerializedName("url")
    @Expose
    private val url: String? = null
}